package com.restaurant.OrderServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.restaurant.jdbc.PostgresqlJDBC;
import com.restaurant.register.RegisterMember;

/**
 * Servlet implementation class Orderservlet
 */
//@WebServlet("/order1")
public class Orderservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Orderservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: karthikeyan ").append(request.getContextPath());
		ServletContext context=getServletContext();
		String RestaurantName=context.getInitParameter("Restaurant-Name");
		System.out.println("Restaurantname is:"+RestaurantName);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String user_order=request.getParameter("user_order");
		String user_id=request.getParameter("user_id");
		RegisterMember member=new RegisterMember();
		RequestDispatcher rd=request.getRequestDispatcher("order.html");
		rd.forward(request, response);
		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","karthikeyan@9944");
			Statement stmt =con.createStatement();
			HttpSession session=request.getSession(false);
			ResultSet rs=stmt.executeQuery("UPDATE user_detail SET user_order = '"+member.getUser_order()+"' WHERE user_id = '"+member.getUser_id()+"'");
			while(rs.next()) {
				session.setAttribute("user_id", rs.getInt(1));
				session.getAttribute("user_id");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
