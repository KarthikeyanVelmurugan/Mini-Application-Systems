package com.restaurant.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class PostgresqlJDBC {
	public Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("org.postgres.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","karthikeyan@9944");
		}catch(Exception e) {
			
		}
		return con;
	}
	
}
