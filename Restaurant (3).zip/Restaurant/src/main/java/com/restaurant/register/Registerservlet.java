package com.restaurant.register;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.restaurant.jdbc.PostgresqlJDBC;

/**
 * Servlet implementation class Registerservlet
 */
//@WebServlet("/register")
public class Registerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registerservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String user_name=request.getParameter("user_name");
		String user_mail=request.getParameter("user_mail"); 
		String user_password=request.getParameter("user_password");
		String user_number=request.getParameter("user_number");
		String user_otp=request.getParameter("user_otp");
		String user_order=request.getParameter("user_order");
		RegisterMember member=new RegisterMember();
		//int user_id=1;
		/*String existingusername=null;
		String existingmail=null;
		String existingupassword=null;*/
		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","karthikeyan@9944");
			PreparedStatement ps =con.prepareStatement("insert into user_detail(user_name,user_password,user_mail,user_number,user_otp,user_order) values(?,?,?,?,?,?)");
			ps.setString(1, user_name);
			ps.setString(2, user_password);
			ps.setString(3, user_mail);
			ps.setString(4, user_number);
			ps.setString(5, user_otp);
			ps.setString(6, member.getUser_order());
			int i=ps.executeUpdate();
			if(i>0) {
				System.out.println("You are sucessfully registered at Simple-hut Restaurant");
				
			}
			else {
				System.out.println("Row is not inserted properly");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher("login.html");
		rd.forward(request, response);
	}

}
