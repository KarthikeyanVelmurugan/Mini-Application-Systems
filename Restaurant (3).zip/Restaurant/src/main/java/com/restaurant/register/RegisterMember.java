package com.restaurant.register;

public class RegisterMember {
	private int user_id;
	private String user_name,user_password,user_mail,user_number,user_otp,user_order;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_mail() {
		return user_mail;
	}
	public void setUser_mail(String user_mail) {
		this.user_mail = user_mail;
	}
	public String getUser_number() {
		return user_number;
	}
	public void setUser_number(String user_number) {
		this.user_number = user_number;
	}
	public String getUser_otp() {
		return user_otp;
	}
	public void setUser_otp(String user_otp) {
		this.user_otp = user_otp;
	}
	public String getUser_order() {
		return user_order;
	}
	public void setUser_order(String user_order) {
		this.user_order = user_order;
	}

}
